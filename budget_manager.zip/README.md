* Fixture load: **python manage.py loaddata currency_fixture.json**
