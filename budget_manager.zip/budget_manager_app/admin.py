from django.contrib import admin
from helper_models.models import Category

admin.site.register(Category)
