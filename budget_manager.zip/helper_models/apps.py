from django.apps import AppConfig


class HelperModelsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "helper_models"
