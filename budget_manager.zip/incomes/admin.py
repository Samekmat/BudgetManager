from django.contrib import admin
from incomes.models import Income

admin.site.register(Income)
