## Functionalities
> - User profile - OK 
> - Authentication - OK 
> - Expense tracking - OK 
> - Income management - OK 
> - CRUD for income and expenses - OK
> - Built-in categories of expenses - OK 
> - CRUD for custom categories of expenses - OK
> - Types and species of expenses (must, need, want) | (cash, card) - OK
> - Display recent payments/expenses - OK
> - Create graph/chart of budget - OK
> - Summary of chosen period (from-to) - OK
> - Create saving goal - OK
> - Currency selection with loading exchange rate - OK
> - Joining someone to shared budget - OK
> - Filter by category and time - OK
> - Toast operations - OK
> - Compare month/category in case of expenses have increased or decreased - OK
> - Scan receipt or invoice (ocr lib) (+ add record from data) - OK
> - Export to csv/pdf - OK
> - Bill reminder - LOW -> REJECT
> - Possibility to add regular payments into home budget -LOW -> REJECT
> - * ~~Reading data from wallets(google) - Not possible / no api~~
> - * ~~Integrate with bank to count expenses and incomes / third app or become a tpp~~ -> Possibility to load csv - OK
> - * Expense forecasting - OK
